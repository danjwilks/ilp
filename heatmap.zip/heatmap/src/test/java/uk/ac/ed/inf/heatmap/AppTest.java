package uk.ac.ed.inf.heatmap;

import static org.junit.Assert.assertTrue;

import org.junit.Test;

public class AppTest {

    @Test
    public void shouldAnswerWithTrue() {
        assertTrue( true );
    }
    
//    @Test
//    public void runApp() {
//    	var args = new String[] {"predictions.txt"};
//    	App.main(args);
//    }
    
}
